import React from 'react'
import './Header.css'

const Header = () => {
  return (
    <div className='header'>
     <div className='logo'>
      <button>logo</button>
      </div> 
      {/* <div className='header1'> */}
     <div className='header__first'>
      <span>All Projects</span>
      </div> 
     <div className='header__second'>
      <span>Datasets</span>
      </div> 
     <div className='header__third'>
      <span>Tasks</span>
      </div> 
     <div className='header__fourth'>
      <span>Bugs</span>
      </div> 
     <div className='header__fifth'>
      <span>ADMIN</span>
      </div> 
     <div className='header__six'>
      <button>Logout</button>
      </div> 
      </div>
    // </div>
  )
}

export default Header
